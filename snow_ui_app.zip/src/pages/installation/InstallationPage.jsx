import React from 'react';


const InstallationPage = (props) => {
  return (
    <div>InstallationPage</div>
  );
};

export default InstallationPage;