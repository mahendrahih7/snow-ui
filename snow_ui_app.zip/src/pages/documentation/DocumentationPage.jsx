import React from 'react';

const DocumentationPage = (props) => {
  return (
    <div>DocumentationPage</div>
  );
};

export default DocumentationPage;