import React from 'react';



const ButtonPage = (props) => {
  return (
    <div>ButtonPage</div>
  );
};

export default ButtonPage;