import React from 'react';

const AlertPage = (props) => {
  return (
    <div>AlertPage</div>
  );
};

export default AlertPage;