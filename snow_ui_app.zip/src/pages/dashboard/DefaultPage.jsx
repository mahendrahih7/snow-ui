import React from 'react';



const DefaultPage = (props) => {
  return (
    <div>DefaultPage</div>
  );
};

export default DefaultPage;