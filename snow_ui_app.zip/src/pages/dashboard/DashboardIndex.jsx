import React from 'react';

const DashboardIndex = (props) => {
  return (
    <div>DashboardIndex</div>
  );
};

export default DashboardIndex;