import React from 'react';



const SaasPage = (props) => {
  return (
    <div>SaasPage</div>
  );
};

export default SaasPage;