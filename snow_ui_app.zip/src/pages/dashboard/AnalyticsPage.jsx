import React from 'react';



const AnalyticsPage = (props) => {
  return (
    <div>AnalyticsPage</div>
  );
};

export default AnalyticsPage;