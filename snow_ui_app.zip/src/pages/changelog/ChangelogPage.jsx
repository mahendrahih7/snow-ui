import React from 'react';


const ChangelogPage = (props) => {
  return (
    <div>ChangelogPage</div>
  );
};

export default ChangelogPage;