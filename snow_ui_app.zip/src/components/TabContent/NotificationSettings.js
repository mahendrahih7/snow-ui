import React from 'react'

const NotificationSettings = () => {
  return (
    <>
     <h2>Notification Setting....</h2> 
    </>
  )
}

export default NotificationSettings
