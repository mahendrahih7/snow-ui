import React from 'react'

const LoyaltySettings = () => {
  return (
    <>
     <h2>Loyalty Settings...</h2> 
    </>
  )
}

export default LoyaltySettings
