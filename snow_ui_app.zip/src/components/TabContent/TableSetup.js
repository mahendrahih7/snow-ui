import React from 'react'

const TableSetup = () => {
  return (
    <>
      <h2>Table setup</h2>
    </>
  )
}

export default TableSetup
