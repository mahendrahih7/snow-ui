import React from 'react'

const OthersSettings = () => {
  return (
    <>
     <h2> Other settings..</h2>
    </>
  )
}

export default OthersSettings
