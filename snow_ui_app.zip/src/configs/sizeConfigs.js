const sizeConfigs = {
  sidebar: {
    width: "300px"
  }
};

export default sizeConfigs;